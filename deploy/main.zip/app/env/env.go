package env

var SQLURI = "postgresql://postgres:Manas@1511200@db.eqodffrathpiujezayka.supabase.co:5432/postgres"
var JWT_SECRET_KEY = "secretKey132"
var JWT_LIFETIME = "14400"
var EMAIL = "testingginbackend@gmail.com"
var PASSWORD = "zqzo musp hpzd ysfx"
