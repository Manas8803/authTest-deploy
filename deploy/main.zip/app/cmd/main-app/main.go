package main

import "app/pkg/main_app"

func main() {
	main_app.Run()
}
