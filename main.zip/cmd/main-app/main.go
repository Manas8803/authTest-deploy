package main

import "authTest/pkg/main_app"

func main() {
	main_app.Run()
}
